<?php
require_once 'config.php';
require_once 'helpers.php';

logout();
?>
